#Project Lead:

    - Gregory M. Kurtzer <gmkurtzer@gmail.com>

#Developers:

    - Brian Bockelman <bbockelm@cse.unl.edu>
    - Krishna Muriki <kmuriki@lbl.gov>
    - Michael Bauer <bauerm@umich.edu>
    - Vanessa Sochat <vsochat@stanford.edu>

#Contributors:

    - Amanda Duffy <aduffy@lenovo.com>
    - Ángel Bejarano <abejarano@ontropos.com>
    - Bernard Li <bernardli@lbl.gov>
    - Dave Love <d.love@liverpool.ac.uk>
    - Felix Abecassis <fabecassis@nvidia.com>
    - Jarrod Johnson <jjohnson2@lenovo.com>
    - Jason Stover <jason.stover@gmail.com>
    - Maciej Sieczka <msieczka@sieczka.org>
    - Nathan Lin <nathan.lin@yale.edu>
    - Ralph Castain <rhc@open-mpi.org>
    - Yaroslav Halchenko <debian@onerussian.com>
    - Eduardo Arango <carlos.arango.gutierrez@correounivalle.edu.co>
    - Oleksandr Moskalenko <om@rc.ufl.edu>
    - Cedric Clerget <cedric.clerget@univ-fcomte.fr>
